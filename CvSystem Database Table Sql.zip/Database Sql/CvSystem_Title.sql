-- MySQL dump 10.13  Distrib 5.7.9, for linux-glibc2.5 (x86_64)
--
-- Host: 80.211.235.22    Database: CvSystem
-- ------------------------------------------------------
-- Server version	5.7.19-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Title`
--

DROP TABLE IF EXISTS `Title`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Title` (
  `idTitle` int(11) NOT NULL AUTO_INCREMENT,
  `parentIdTitle` int(11) DEFAULT NULL,
  `title` varchar(45) COLLATE utf8_turkish_ci DEFAULT NULL,
  PRIMARY KEY (`idTitle`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Title`
--

LOCK TABLES `Title` WRITE;
/*!40000 ALTER TABLE `Title` DISABLE KEYS */;
INSERT INTO `Title` VALUES (1,0,'Personal Info'),(2,0,'Jop Experience'),(3,0,'Education'),(4,1,'Date Of Birth'),(5,1,'Martial Status'),(6,3,'School Name'),(7,3,'Departman Name'),(8,1,'Name Surname'),(9,1,'Foto Path'),(10,1,'Objective'),(11,1,'Office Phone'),(12,0,'Projects'),(13,1,'Adress'),(14,2,'Company Name'),(15,2,'Jop Title'),(16,2,'Jop Experience Start Date'),(17,2,'Jop Explanation'),(19,0,'Foreign Languages'),(20,19,'Name Of Language'),(24,0,'Skills'),(25,0,'Courses and Seminars'),(26,0,'Certificates'),(27,0,'Publications'),(28,1,'Cell Phone'),(29,1,'Personal Info Title'),(30,2,'Jop Experience End Date'),(31,12,'Projects Description'),(32,19,'Language Level'),(33,25,'Courses and Seminars Description'),(34,26,'Certificates Description'),(35,27,'Publications Description'),(36,3,'Education Start Date'),(37,3,'Education End Date'),(38,3,'Education Description'),(39,24,'Skills Description'),(40,1,'E-Mail Adress');
/*!40000 ALTER TABLE `Title` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-09-10 11:59:47
