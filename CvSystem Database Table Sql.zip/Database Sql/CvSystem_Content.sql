-- MySQL dump 10.13  Distrib 5.7.9, for linux-glibc2.5 (x86_64)
--
-- Host: 80.211.235.22    Database: CvSystem
-- ------------------------------------------------------
-- Server version	5.7.19-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Content`
--

DROP TABLE IF EXISTS `Content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Content` (
  `idContent` int(11) NOT NULL AUTO_INCREMENT,
  `cvId` int(11) DEFAULT NULL,
  `titleId` int(11) DEFAULT NULL,
  `content` text COLLATE utf8_turkish_ci,
  PRIMARY KEY (`idContent`),
  KEY `fk_Content_1_idx` (`titleId`),
  KEY `fk_Content_2_idx` (`cvId`),
  CONSTRAINT `fk_Content_1` FOREIGN KEY (`titleId`) REFERENCES `Title` (`idTitle`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Content_2` FOREIGN KEY (`cvId`) REFERENCES `Cv` (`idCv`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6716 DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Content`
--

LOCK TABLES `Content` WRITE;
/*!40000 ALTER TABLE `Content` DISABLE KEYS */;
INSERT INTO `Content` VALUES (5779,216,8,'ilker güldal?'),(5780,216,29,'sofware developer'),(5781,216,10,'       Objectives'),(5782,216,4,'01-01-2011'),(5783,216,28,'05350836860'),(5784,216,11,''),(5785,216,13,'Mehmet Akif Ersoy Cad\r\nNo 32 Daire 1'),(5786,216,5,'Single'),(5787,216,40,'guldaliilker@gmail.com'),(5788,216,9,'profilePhoto/120170905162157.jpeg'),(5789,216,14,'32Bit'),(5790,216,15,'Full Stack Developer'),(5791,216,16,'2016'),(5792,216,30,'2017'),(5793,216,17,'32Bit aciklamasi'),(5794,216,14,'82Bit'),(5795,216,15,'Full Stack Developer'),(5796,216,16,'1'),(5797,216,17,'desc'),(5798,216,14,'64bit'),(5799,216,15,'Stajyer'),(5800,216,16,'2017'),(5801,216,30,'2018'),(5802,216,17,'64bit aç?klamas?'),(5803,216,6,'Ataturk ilkogretim okulu'),(5804,216,7,'ilkokul'),(5805,216,36,'09/05/2017'),(5806,216,37,'09/05/2017'),(5807,216,38,'ataturk aciklama'),(5808,216,31,'proje1\r\nproje2\r\nproje 3\r\nproje 4\r\n'),(5809,216,20,'Almanca'),(5810,216,32,'Good'),(5811,216,20,'Ingilizce'),(5812,216,32,'Beginning'),(5813,216,39,'c#,c++,java'),(5814,216,33,'c1\r\nc2\r\nc3\r\ns1\r\ns2'),(5815,216,34,'cer1\r\ncer2\r\ncer3\r\n'),(5816,216,35,'pub1\r\npub2\r\npub3'),(5851,218,8,'ilker'),(5852,218,29,'sofware developer'),(5853,218,10,'  objectives'),(5854,218,4,'09-27-2017'),(5855,218,28,'05350836860'),(5856,218,11,'05350836860'),(5857,218,13,'Mehmet Akif Ersoy Cad\r\nNo 32 Daire 1'),(5858,218,5,'Single'),(5859,218,40,'guldaliilker@gmail.com'),(5860,218,9,'profilePhoto/120170903163238.jpeg'),(5861,218,14,'32Bit'),(5862,218,15,'Full Stack Developer'),(5863,218,16,'09/03/2017'),(5864,218,30,'09/03/2017'),(5865,218,17,'32bit aciklama'),(5866,218,6,'Ataturk ilkogretim okulu'),(5867,218,7,'ilkogretim'),(5868,218,36,'09/03/2017'),(5869,218,37,'09/03/2017'),(5870,218,38,'ataturk desc'),(5871,218,6,'aibu'),(5872,218,7,'bilgisayar muh'),(5873,218,36,'2012-04-05'),(5874,218,37,'2012-04-19'),(5875,218,38,'aibu desc'),(5876,218,31,'project'),(5877,218,20,'Almanca'),(5878,218,20,'Ingilizce'),(5879,218,32,'Advanced'),(5880,218,39,'s'),(5881,218,33,'courses'),(5882,218,34,'cert'),(5883,218,35,'pub'),(6038,223,8,'ilker güldalı'),(6039,223,29,'d'),(6040,223,10,'   d'),(6041,223,4,'d'),(6042,223,28,'1'),(6043,223,11,'2'),(6044,223,13,'Gebze'),(6045,223,5,'Single'),(6046,223,40,'d'),(6047,223,9,'profilePhoto/120170905185044.jpeg'),(6048,223,14,'32Bit'),(6049,223,15,'Full Stack Developer'),(6050,223,16,'2016'),(6051,223,30,'2017'),(6052,223,17,'desc1'),(6053,223,14,'64bit'),(6054,223,15,'Stajyer'),(6055,223,16,'2017'),(6056,223,30,'2018'),(6057,223,17,'desc2'),(6058,223,6,'edu1'),(6059,223,7,'ilkokul'),(6060,223,36,'12'),(6061,223,37,'13'),(6062,223,38,'desc1'),(6063,223,6,'edu22'),(6064,223,7,'bilgisayar muh'),(6065,223,36,'22'),(6066,223,37,'23'),(6067,223,38,'desc2'),(6068,223,6,'edu3'),(6069,223,7,'33'),(6070,223,36,'31'),(6071,223,37,'32'),(6072,223,38,'33'),(6073,223,31,'pro'),(6074,223,20,'Ingilizce'),(6075,223,32,'Beginning'),(6076,223,20,'Almanca'),(6077,223,32,'Good'),(6078,223,39,'deneme,deneme2'),(6079,223,33,'courses'),(6080,223,34,'certificates'),(6081,223,35,'publi'),(6440,239,8,'ilker guldali'),(6441,239,29,'sofware developer'),(6442,239,10,'   Objectives'),(6443,239,4,'12.12.1997'),(6444,239,28,'05350836860'),(6445,239,11,'0850'),(6446,239,13,'Mehmet Akif Ersoy Cad\r\nNo 32 Daire 1'),(6447,239,5,'Married'),(6448,239,40,'guldaliilker@gmail.com'),(6449,239,9,'profilePhoto/120170906001943.jpeg'),(6450,239,14,'32Bit'),(6451,239,15,'Full Stack Developer'),(6452,239,16,'2016'),(6453,239,30,'2017'),(6454,239,17,'32Bit aciklama'),(6455,239,14,'64Bit'),(6456,239,15,'Çaycı'),(6457,239,16,'2012'),(6458,239,30,'2013'),(6459,239,17,'Çay taşıma'),(6460,239,14,'81Bit'),(6461,239,15,'Terlik'),(6462,239,16,'2009'),(6463,239,30,'2011'),(6464,239,17,'araç'),(6465,239,6,'Ataturk ilkogretim okulu'),(6466,239,7,'ilkokul'),(6467,239,36,'2011'),(6468,239,37,'2012'),(6469,239,38,'Education '),(6470,239,31,'project'),(6471,239,20,'Almanca'),(6472,239,32,'Intermediate'),(6473,239,20,'Ingilizce'),(6474,239,32,'Good'),(6475,239,39,'c,c#,c++'),(6476,239,33,'Courses\r\nand\r\nseminars\r\n'),(6477,239,34,'cert\r\nficates\r\n'),(6478,239,35,'publi\r\ncations'),(6479,240,8,'Adam West'),(6480,240,29,'Web Developer'),(6481,240,10,'Web Developer with 8 years of experience in designing and developing user interfaces, testing, debugging, and training staff within eCommerce technologies. Proven ability in optimizing web functionality that improve data retrieval and workflow efficiencies.'),(6482,240,4,'04-11-1963'),(6483,240,28,'(714) 463-7533'),(6484,240,11,''),(6485,240,13,'200 West Commonwealth Avenue, Fullerton, CA 92832'),(6486,240,5,'Single'),(6487,240,40,'adam.west@gmail.com'),(6488,240,9,'profilePhoto/3420170906002652.jpeg'),(6489,240,14,'FOCUS SOLUTIONS '),(6490,240,15,'Web Developer '),(6491,240,16,'Jun 2007'),(6492,240,30,'Apr 2010'),(6493,240,17,'Developed dynamic and interactive website that ensured high traffic, page views, and User Experience, resulting in 40% increase in sales revenue'),(6494,240,6,'CALIFORNIA STATE UNIVERSITY Fullerton, CA'),(6495,240,7,'Bachelor of Science in Web Development'),(6496,240,36,'2001'),(6497,240,37,'2006'),(6498,240,38,'GPA: 3.6/4.0'),(6499,240,31,'Facebook Bug Fixed - '),(6500,240,20,'German'),(6501,240,32,'Beginning'),(6502,240,39,'ASP, SQL, JavaScript, Visual Basic, XML, C#, Ajax, HTML'),(6503,240,33,'Courses'),(6504,240,34,'Certified Java Programmer'),(6505,240,35,'Java for Beginner'),(6506,241,8,'John Smith'),(6507,241,29,'Android Developer'),(6508,241,10,'A forward thinking developer offering more than four years of experience building, integrating, testing and supporting Android applications for mobile and tablet devices on the Android platform.'),(6509,241,4,'04.05.1963'),(6510,241,28,'123.456.7890'),(6511,241,11,''),(6512,241,13,'125 First Street Austin, TX 78610'),(6513,241,5,'Married'),(6514,241,40,'johnsmith@abcmail.com'),(6515,241,9,'profilePhoto/120170906010109.jpeg'),(6516,241,14,'ABC Corporation  '),(6517,241,15,'Android Developer'),(6518,241,16,'Jan 2011'),(6519,241,30,'Nov 2015'),(6520,241,17,'Project lead of mobile development team for various ABC Corporation Android projects. Collaborate with marketing, key executives, UI designers, and other developers to develop cutting-edge applications for the financial sector without jeopardizing data privacy or security.'),(6521,241,14,' XYZ Gaming '),(6522,241,15,'Android Developer'),(6523,241,16,'May 2006'),(6524,241,30,'Sep 2008'),(6525,241,17,'Worked with architects, engineering, and product management to deliver user-friendly and visually appealing mobile games for the Android platform.'),(6526,241,6,'University of Harvard'),(6527,241,7,'Bachelor of Science, Computer Science'),(6528,241,36,'1972'),(6529,241,37,'1978'),(6530,241,38,'Lorem ipsum sit amet'),(6531,241,31,'Puzzle 3D\r\nDriving Car'),(6532,241,20,'English'),(6533,241,32,'Advanced'),(6534,241,20,'Turkish'),(6535,241,32,'Beginning'),(6536,241,39,'Java, JavaScript, C#, Ruby, Python'),(6537,241,33,'Android 101\r\nAndroid 102'),(6538,241,34,'Sun Certified Java Developer (SCJD)'),(6539,241,35,'How to be Android Person?'),(6655,246,8,'Deepak Jhaveri'),(6656,246,29,'Software Developer'),(6657,246,10,'      To secure a job in the IT industry where I can utilize my knowledge for the organization’s growth.'),(6658,246,4,'09-04-2017'),(6659,246,28,'+91-551-789-42-52'),(6660,246,11,''),(6661,246,13,'Cecilia Chapman\r\n711-2880 Nulla St.\r\nMankato Mississippi 96522'),(6662,246,5,'Single'),(6663,246,40,'Jhaveri@gmail.com'),(6664,246,9,'profilePhoto/3320170906140231.jpeg'),(6665,246,14,'Teletron Inc.'),(6666,246,15,'Computer Engineer'),(6667,246,16,'09/04/2017'),(6668,246,30,'09/04/2017'),(6669,246,17,'Supervise team testing in-development products. Observe and document system and component performance.Write and compile user manuals for completed systems.\r\n'),(6670,246,14,'Computer Engineer'),(6671,246,15,'Computer Engineer'),(6672,246,16,'09/04/2017'),(6673,246,30,'09/04/2017'),(6674,246,17,'Oversaw design of system electrical components. Completed cost-benefit analysis for each system and component.Troubleshot malfunctions and wrote reports detailing findings.\r\n'),(6675,246,6,'University of Missouri'),(6676,246,7,'Bachelor of Science - Computer Science'),(6677,246,36,'09/04/2017'),(6678,246,37,'09/04/2017'),(6679,246,38,' '),(6680,246,31,'Placement Office Automation\r\nBig Bazar Management\r\nStudent Counseling'),(6681,246,20,'English'),(6682,246,32,'Advanced'),(6683,246,20,'French'),(6684,246,32,'Good'),(6685,246,39,'C,C++,Java,MySql,HTML,JavaScript,Mac Usage,JEE'),(6686,246,33,''),(6687,246,34,'Secured III rank in XCV Event in IIT.\r\nOrganized national level technical symposiums in my college.\r\nParticipated in various Inter-school competitions and was awarded for performing excellent.'),(6688,246,35,'');
/*!40000 ALTER TABLE `Content` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-09-10 11:59:41
